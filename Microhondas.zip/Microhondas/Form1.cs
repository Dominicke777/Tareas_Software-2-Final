
using System.CodeDom.Compiler;
using System.Drawing.Text;

namespace Microhondas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //declarar una varibale de tipo string para almacenar lo que el usuario digita con un tiempo
        string tiempo = "";
        Timer temporizador;

        private void DisplayTime()
        {
            //aqui tomamos lo que tiene la variable
            //tiempo y lo convertimos a un formato de hh:mm:ss
            int horas, minutos, segundos;

            //nos aseguraremos que el tiempo tenga mas de 5 caracteres
            if (tiempo.Length == 5)
            {
                //extraemos las horas

                tiempo = tiempo.Substring(0, 5);
            }
            string display;
            display = tiempo.PadLeft(5, '0');

            horas = int.Parse(display.Substring(0, 1));
            minutos = int.Parse(display.Substring(1, 2));
            segundos = int.Parse(display.Substring(3, 2));

            if (horas > 9)
            {
                horas = 9;
            }
            if (minutos > 59)
            {
                minutos = 59;
            }
            if (segundos > 59)
            {
                segundos = 59;
            }

            lblPantalla.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", horas, minutos, segundos);
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            //concatenamos el valor del boton al tiempo
            tiempo = tiempo + btn1.Text;

            //mostramos en pantalla
            DisplayTime();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn2.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            // Si el temporizador ya est� configurado, simplemente reanudar
            if (temporizador != null && (temporizador.Horas > 0 || temporizador.Minutos > 0 || temporizador.Segundos > 0))
            {
                timer1.Enabled = true;
                pnlPrincipal.BackColor = Color.Green;
                return;
            }

            // Si no hay un temporizador configurado, inicializar uno nuevo
            tiempo = tiempo.PadLeft(5, '0');

            int horas = int.Parse(tiempo.Substring(0, 1));
            int minutos = int.Parse(tiempo.Substring(1, 2));
            int segundos = int.Parse(tiempo.Substring(3, 2));

            temporizador = new Timer(horas, minutos, segundos);

            lblPantalla.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", temporizador.Horas, temporizador.Minutos, temporizador.Segundos);

            timer1.Enabled = true;
            pnlPrincipal.BackColor = Color.Green;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            //declaramos nuestro tiempo 

            if (temporizador.Segundos > 0)
            {
                temporizador.Segundos--;
            }
            else if (temporizador.Minutos > 0)
            {
                temporizador.Minutos--;
                temporizador.Segundos = 59;
            }
            else if (temporizador.Horas > 0)
            {
                temporizador.Horas--;
                temporizador.Minutos = 59;
                temporizador.Segundos = 59;
            }
            else
            {
                timer1.Enabled = false;
                lblPantalla.Text = "Fin";
                tiempo = "";
                pnlPrincipal.BackColor = SystemColors.Control;
            }

            if (temporizador.Horas == 0 && temporizador.Minutos == 0 && temporizador.Segundos == 0)
            {
                lblPantalla.Text = "Fin";
            }
            else
            {
                lblPantalla.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", temporizador.Horas, temporizador.Minutos, temporizador.Segundos);
            }

            lblPantalla.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", temporizador.Horas, temporizador.Minutos, temporizador.Segundos);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn3.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn4.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn5.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn6.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn7.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn8.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn9.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            tiempo = tiempo + btn0.Text;
            //mostramos en pantalla
            DisplayTime();
        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            // Detener el temporizador
            timer1.Enabled = false;

            // Restablecer el color de fondo del panel principal
            pnlPrincipal.BackColor = SystemColors.Control;

            // Mostrar el tiempo restante en la pantalla
            lblPantalla.Text = string.Format("{0:D2}:{1:D2}:{2:D2}", temporizador.Horas, temporizador.Minutos, temporizador.Segundos);
        }


    }
}
