﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microhondas
{
    internal class Timer
    {
        //atributos
        private int _segundos;
        private int _minutos;
        private int _horas;

        //propiedad para controlar accesos
        public int Horas
        {
            get { return _horas; }
            set
            {
                if (value < 24)
                {
                    _horas = value;
                }
                else
                {
                    _horas = 0;
                }
            }
        }

        public int Minutos
        {
            get { return _minutos; }
            set
            {
                if (value < 60)
                {
                    _minutos = value;
                }
                else
                {
                    _minutos = 0;
                }
            }
        }

        public int Segundos
        {
            get { return _segundos; }
            set
            {
                if (value < 60)
                {
                    _segundos = value;
                }
                else
                {
                    _segundos = 0;
                }
            }
        }

        //constructor

        public Timer(int horas, int minutos, int segundos)

        { 
            Horas = horas;
            Minutos = minutos;
            Segundos = segundos;

        }
    }
}