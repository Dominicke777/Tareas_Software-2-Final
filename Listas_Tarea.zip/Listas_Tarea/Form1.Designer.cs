﻿namespace Listas_Tarea
{
    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAgregarLista1 = new System.Windows.Forms.Button();
            this.btnBorrarLista1 = new System.Windows.Forms.Button();
            this.btnBorrarTodoLista1 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAgregarLista2 = new System.Windows.Forms.Button();
            this.btnBorrarLista2 = new System.Windows.Forms.Button();
            this.btnBorrarTodoLista2 = new System.Windows.Forms.Button();
            this.btnMoverDerecha = new System.Windows.Forms.Button();
            this.btnMoverIzquierda = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 38);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(200, 160);
            this.listBox1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lista Ordenada";
            // 
            // btnAgregarLista1
            // 
            this.btnAgregarLista1.Location = new System.Drawing.Point(12, 204);
            this.btnAgregarLista1.Name = "btnAgregarLista1";
            this.btnAgregarLista1.Size = new System.Drawing.Size(200, 23);
            this.btnAgregarLista1.TabIndex = 2;
            this.btnAgregarLista1.Text = "Agregar Elemento";
            this.btnAgregarLista1.UseVisualStyleBackColor = true;
            this.btnAgregarLista1.Click += new System.EventHandler(this.btnAgregarLista1_Click);
            // 
            // btnBorrarLista1
            // 
            this.btnBorrarLista1.Location = new System.Drawing.Point(12, 233);
            this.btnBorrarLista1.Name = "btnBorrarLista1";
            this.btnBorrarLista1.Size = new System.Drawing.Size(200, 23);
            this.btnBorrarLista1.TabIndex = 3;
            this.btnBorrarLista1.Text = "Borrar Elemento";
            this.btnBorrarLista1.UseVisualStyleBackColor = true;
            this.btnBorrarLista1.Click += new System.EventHandler(this.btnBorrarLista1_Click);
            // 
            // btnBorrarTodoLista1
            // 
            this.btnBorrarTodoLista1.Location = new System.Drawing.Point(12, 262);
            this.btnBorrarTodoLista1.Name = "btnBorrarTodoLista1";
            this.btnBorrarTodoLista1.Size = new System.Drawing.Size(200, 23);
            this.btnBorrarTodoLista1.TabIndex = 4;
            this.btnBorrarTodoLista1.Text = "Borrar Lista";
            this.btnBorrarTodoLista1.UseVisualStyleBackColor = true;
            this.btnBorrarTodoLista1.Click += new System.EventHandler(this.btnBorrarTodoLista1_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(276, 38);
            this.listBox2.Name = "listBox2";
            this.listBox2.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBox2.Size = new System.Drawing.Size(200, 160);
            this.listBox2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(273, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Lista sin ordenar";
            // 
            // btnAgregarLista2
            // 
            this.btnAgregarLista2.Location = new System.Drawing.Point(276, 204);
            this.btnAgregarLista2.Name = "btnAgregarLista2";
            this.btnAgregarLista2.Size = new System.Drawing.Size(200, 23);
            this.btnAgregarLista2.TabIndex = 7;
            this.btnAgregarLista2.Text = "Agregar Elemento";
            this.btnAgregarLista2.UseVisualStyleBackColor = true;
            this.btnAgregarLista2.Click += new System.EventHandler(this.btnAgregarLista2_Click);
            // 
            // btnBorrarLista2
            // 
            this.btnBorrarLista2.Location = new System.Drawing.Point(276, 233);
            this.btnBorrarLista2.Name = "btnBorrarLista2";
            this.btnBorrarLista2.Size = new System.Drawing.Size(200, 23);
            this.btnBorrarLista2.TabIndex = 8;
            this.btnBorrarLista2.Text = "Borrar Elemento";
            this.btnBorrarLista2.UseVisualStyleBackColor = true;
            this.btnBorrarLista2.Click += new System.EventHandler(this.btnBorrarLista2_Click);
            // 
            // btnBorrarTodoLista2
            // 
            this.btnBorrarTodoLista2.Location = new System.Drawing.Point(276, 262);
            this.btnBorrarTodoLista2.Name = "btnBorrarTodoLista2";
            this.btnBorrarTodoLista2.Size = new System.Drawing.Size(200, 23);
            this.btnBorrarTodoLista2.TabIndex = 9;
            this.btnBorrarTodoLista2.Text = "Borrar Lista";
            this.btnBorrarTodoLista2.UseVisualStyleBackColor = true;
            this.btnBorrarTodoLista2.Click += new System.EventHandler(this.btnBorrarTodoLista2_Click);
            // 
            // btnMoverDerecha
            // 
            this.btnMoverDerecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoverDerecha.Location = new System.Drawing.Point(218, 88);
            this.btnMoverDerecha.Name = "btnMoverDerecha";
            this.btnMoverDerecha.Size = new System.Drawing.Size(52, 23);
            this.btnMoverDerecha.TabIndex = 10;
            this.btnMoverDerecha.Text = ">>>";
            this.btnMoverDerecha.UseVisualStyleBackColor = true;
            this.btnMoverDerecha.Click += new System.EventHandler(this.btnMoverDerecha_Click);
            // 
            // btnMoverIzquierda
            // 
            this.btnMoverIzquierda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMoverIzquierda.Location = new System.Drawing.Point(218, 117);
            this.btnMoverIzquierda.Name = "btnMoverIzquierda";
            this.btnMoverIzquierda.Size = new System.Drawing.Size(52, 23);
            this.btnMoverIzquierda.TabIndex = 11;
            this.btnMoverIzquierda.Text = "<<<";
            this.btnMoverIzquierda.UseVisualStyleBackColor = true;
            this.btnMoverIzquierda.Click += new System.EventHandler(this.btnMoverIzquierda_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 301);
            this.Controls.Add(this.btnMoverIzquierda);
            this.Controls.Add(this.btnMoverDerecha);
            this.Controls.Add(this.btnBorrarTodoLista2);
            this.Controls.Add(this.btnBorrarLista2);
            this.Controls.Add(this.btnAgregarLista2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.btnBorrarTodoLista1);
            this.Controls.Add(this.btnBorrarLista1);
            this.Controls.Add(this.btnAgregarLista1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Listas Ordenadas y No Ordenadas";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAgregarLista1;
        private System.Windows.Forms.Button btnBorrarLista1;
        private System.Windows.Forms.Button btnBorrarTodoLista1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAgregarLista2;
        private System.Windows.Forms.Button btnBorrarLista2;
        private System.Windows.Forms.Button btnBorrarTodoLista2;
        private System.Windows.Forms.Button btnMoverDerecha;
        private System.Windows.Forms.Button btnMoverIzquierda;
    }
}
