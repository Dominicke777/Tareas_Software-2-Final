using System.Windows.Forms;

namespace Listas_Tarea
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            // Configurar las propiedades de selecci�n de las listas
            listBox1.SelectionMode = SelectionMode.One; // Solo un elemento seleccionable
            listBox2.SelectionMode = SelectionMode.MultiExtended; // M�ltiples elementos seleccionables
        }

        private void btnAgregarLista1_Click(object sender, EventArgs e)
        {
            string nuevoElemento = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el elemento a agregar:", "Agregar Elemento");

            if (!string.IsNullOrWhiteSpace(nuevoElemento))
            {
                if (listBox1.Items.Count == 0)
                {
                    listBox1.Items.Add(nuevoElemento);
                }
                else
                {
                    MessageBox.Show("La lista ordenada solo puede contener un elemento.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnBorrarLista1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Seleccione un elemento para borrar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnBorrarTodoLista1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnAgregarLista2_Click(object sender, EventArgs e)
        {
            string nuevoElemento = Microsoft.VisualBasic.Interaction.InputBox("Ingrese el elemento a agregar:", "Agregar Elemento");

            if (!string.IsNullOrWhiteSpace(nuevoElemento))
            {
                listBox2.Items.Add(nuevoElemento);
            }
        }

        private void btnBorrarLista2_Click(object sender, EventArgs e)
        {
            // Crear una lista temporal para almacenar los �ndices seleccionados
            List<int> indicesSeleccionados = new List<int>();

            foreach (int index in listBox2.SelectedIndices)
            {
                indicesSeleccionados.Add(index);
            }

            // Ordenar de mayor a menor para evitar problemas con los �ndices al borrar
            indicesSeleccionados.Sort();
            indicesSeleccionados.Reverse();

            foreach (int index in indicesSeleccionados)
            {
                listBox2.Items.RemoveAt(index);
            }
        }

        private void btnBorrarTodoLista2_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void btnMoverDerecha_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string elemento = listBox1.SelectedItem.ToString();
                listBox2.Items.Add(elemento);
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Seleccione un elemento para mover.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnMoverIzquierda_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndices.Count > 0)
            {
                // Verificar si la lista izquierda est� vac�a
                if (listBox1.Items.Count == 0)
                {
                    // Solo mover el primer elemento seleccionado (para mantener la regla de un solo elemento)
                    string elemento = listBox2.SelectedItem.ToString();
                    listBox1.Items.Add(elemento);
                    listBox2.Items.RemoveAt(listBox2.SelectedIndex);
                }
                else
                {
                    MessageBox.Show("La lista ordenada solo puede contener un elemento.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Seleccione al menos un elemento para mover.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
