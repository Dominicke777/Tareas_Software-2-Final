﻿namespace ParqueAtraccione_Tarea
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido al sistema de cálculo de entradas");
            Console.WriteLine("--------------------------------------------\n");

            // Solicitar altura  
            int altura = 0;
            bool alturaValida = false;
            while (!alturaValida)
            {
                Console.Write("Ingrese su altura en cm: ");
                string inputAltura = Console.ReadLine();

                if (int.TryParse(inputAltura, out altura) && altura > 0)
                {
                    alturaValida = true;
                }
                else
                {
                    Console.WriteLine("Por favor ingrese un valor numérico válido para la altura.\n");
                }
            }

            // Verificar altura mínima  
            if (altura < 120)
            {
                Console.WriteLine("\nLo sentimos, no cumple con la altura mínima requerida de 120 cm para subir a la atracción.");
                Console.WriteLine("Presione cualquier tecla para salir...");
                Console.ReadKey();
                return;
            }

            // Inicializar fechaNacimiento para evitar el error CS0165  
            DateTime fechaNacimiento = DateTime.MinValue;
            bool fechaValida = false;
            while (!fechaValida)
            {
                Console.Write("\nIngrese su fecha de nacimiento (dd/mm/aaaa): ");
                string inputFecha = Console.ReadLine();

                if (DateTime.TryParse(inputFecha, out fechaNacimiento))
                {
                    if (fechaNacimiento > DateTime.Now)
                    {
                        Console.WriteLine("La fecha de nacimiento no puede ser futura. Intente nuevamente.");
                    }
                    else
                    {
                        fechaValida = true;
                    }
                }
                else
                {
                    Console.WriteLine("Formato de fecha inválido. Use el formato dd/mm/aaaa.");
                }
            }

            // Calcular edad  
            int edad = CalcularEdad(fechaNacimiento);

            // Calcular precio base  
            decimal precio = 0;
            string mensajeTarifa = "";

            if (edad < 12)
            {
                precio = 5m;
                mensajeTarifa = "Tarifa infantil (menos de 12 años): $5";
            }
            else if (edad >= 12 && edad <= 17)
            {
                precio = 7m;
                mensajeTarifa = "Tarifa juvenil (12-17 años): $7";
            }
            else if (edad >= 18 && edad < 45)
            {
                precio = 12m;
                mensajeTarifa = "Tarifa adulto (18-44 años): $12";
            }
            else if (edad >= 45 && edad <= 55)
            {
                precio = 0m;
                mensajeTarifa = "¡Adulto mayor (45-55 años)! Entrada GRATIS";
            }
            else
            {
                precio = 12m;
                mensajeTarifa = "Tarifa estándar (mayor de 55 años): $12";
            }

            // Preguntar por foto opcional  
            Console.Write("\n¿Desea tomarse una foto por $3 adicionales? (s/n): ");
            string opcionFoto = Console.ReadLine().ToLower();

            bool fotoSeleccionada = opcionFoto == "s" || opcionFoto == "si";
            if (fotoSeleccionada)
            {
                precio += 3m;
                mensajeTarifa += "\n+ Foto opcional: $3";
            }

            // Mostrar resultados  
            Console.WriteLine("\n--------------------------------------------");
            Console.WriteLine("Resumen de su entrada:");
            Console.WriteLine($"- Altura: {altura} cm (Cumple con el requisito)");
            Console.WriteLine($"- Edad: {edad} años");
            Console.WriteLine($"- {mensajeTarifa}");
            Console.WriteLine($"\nTOTAL A PAGAR: ${precio}");
            Console.WriteLine("--------------------------------------------");

            Console.WriteLine("\nPresione cualquier tecla para salir...");
            Console.ReadKey();
        }

        static int CalcularEdad(DateTime fechaNacimiento)
        {
            DateTime hoy = DateTime.Today;
            int edad = hoy.Year - fechaNacimiento.Year;

            // Ajustar si aún no ha pasado el cumpleaños este año  
            if (fechaNacimiento.Date > hoy.AddYears(-edad))
            {
                edad--;
            }

            return edad;
        }
    }
}
