﻿namespace Invoice_Tarea
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            btnSave = new Button();
            btnCalculate = new Button();
            btnClear = new Button();
            txtInvoiceNumber = new TextBox();
            txtInvoiceDate = new TextBox();
            txtCompanyName = new TextBox();
            txtAddress2 = new TextBox();
            txtAddress1 = new TextBox();
            txtQuantity24 = new TextBox();
            txtPrice32 = new TextBox();
            txtPrice27 = new TextBox();
            txtPrice24 = new TextBox();
            txtQuantity32 = new TextBox();
            txtQuantity27 = new TextBox();
            txtTotal24 = new TextBox();
            txtTotal27 = new TextBox();
            txtTotal32 = new TextBox();
            txtSubtotal = new TextBox();
            txtTaxes = new TextBox();
            txtFinalTotal = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(88, 19);
            label1.Name = "label1";
            label1.Size = new Size(645, 62);
            label1.TabIndex = 0;
            label1.Text = "Monitor Invoice Application";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(494, 586);
            label4.Name = "label4";
            label4.Size = new Size(43, 20);
            label4.TabIndex = 3;
            label4.Text = "total:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(494, 554);
            label5.Name = "label5";
            label5.Size = new Size(44, 20);
            label5.TabIndex = 4;
            label5.Text = "Taxes";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(494, 517);
            label6.Name = "label6";
            label6.Size = new Size(68, 20);
            label6.TabIndex = 5;
            label6.Text = "Subtotal:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(308, 350);
            label7.Name = "label7";
            label7.Size = new Size(68, 20);
            label7.TabIndex = 6;
            label7.Text = "Quantity:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(166, 392);
            label8.Name = "label8";
            label8.Size = new Size(34, 20);
            label8.TabIndex = 7;
            label8.Text = "24\":";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(52, 285);
            label9.Name = "label9";
            label9.Size = new Size(114, 20);
            label9.TabIndex = 8;
            label9.Text = "Address(Line 2):";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(166, 475);
            label10.Name = "label10";
            label10.Size = new Size(34, 20);
            label10.TabIndex = 9;
            label10.Text = "32\":";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(698, 350);
            label11.Name = "label11";
            label11.Size = new Size(51, 20);
            label11.TabIndex = 10;
            label11.Text = "Totals:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(504, 350);
            label12.Name = "label12";
            label12.Size = new Size(44, 20);
            label12.TabIndex = 11;
            label12.Text = "Price:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(166, 438);
            label13.Name = "label13";
            label13.Size = new Size(34, 20);
            label13.TabIndex = 12;
            label13.Text = "27\":";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(166, 350);
            label14.Name = "label14";
            label14.Size = new Size(43, 20);
            label14.TabIndex = 13;
            label14.Text = "Type:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(52, 238);
            label15.Name = "label15";
            label15.Size = new Size(108, 20);
            label15.TabIndex = 14;
            label15.Text = "Addres(Line 1):";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(52, 190);
            label16.Name = "label16";
            label16.Size = new Size(116, 20);
            label16.TabIndex = 15;
            label16.Text = "Company name:";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(423, 112);
            label17.Name = "label17";
            label17.Size = new Size(95, 20);
            label17.TabIndex = 16;
            label17.Text = "Invoice Date:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(52, 112);
            label18.Name = "label18";
            label18.Size = new Size(117, 20);
            label18.TabIndex = 17;
            label18.Text = "Invoice Number:";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(34, 569);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(106, 55);
            btnSave.TabIndex = 18;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(175, 569);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(106, 55);
            btnCalculate.TabIndex = 19;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(332, 569);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(106, 55);
            btnClear.TabIndex = 20;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // txtInvoiceNumber
            // 
            txtInvoiceNumber.Location = new Point(191, 110);
            txtInvoiceNumber.Name = "txtInvoiceNumber";
            txtInvoiceNumber.Size = new Size(178, 27);
            txtInvoiceNumber.TabIndex = 21;
            // 
            // txtInvoiceDate
            // 
            txtInvoiceDate.Location = new Point(526, 105);
            txtInvoiceDate.Name = "txtInvoiceDate";
            txtInvoiceDate.Size = new Size(178, 27);
            txtInvoiceDate.TabIndex = 22;
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(175, 187);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(413, 27);
            txtCompanyName.TabIndex = 23;
            // 
            // txtAddress2
            // 
            txtAddress2.Location = new Point(175, 278);
            txtAddress2.Name = "txtAddress2";
            txtAddress2.Size = new Size(413, 27);
            txtAddress2.TabIndex = 24;
            // 
            // txtAddress1
            // 
            txtAddress1.Location = new Point(175, 231);
            txtAddress1.Name = "txtAddress1";
            txtAddress1.Size = new Size(413, 27);
            txtAddress1.TabIndex = 25;
            // 
            // txtQuantity24
            // 
            txtQuantity24.Location = new Point(260, 385);
            txtQuantity24.Name = "txtQuantity24";
            txtQuantity24.Size = new Size(178, 27);
            txtQuantity24.TabIndex = 26;
            // 
            // txtPrice32
            // 
            txtPrice32.Location = new Point(460, 472);
            txtPrice32.Name = "txtPrice32";
            txtPrice32.Size = new Size(154, 27);
            txtPrice32.TabIndex = 27;
            // 
            // txtPrice27
            // 
            txtPrice27.Location = new Point(460, 431);
            txtPrice27.Name = "txtPrice27";
            txtPrice27.Size = new Size(154, 27);
            txtPrice27.TabIndex = 28;
            // 
            // txtPrice24
            // 
            txtPrice24.Location = new Point(460, 385);
            txtPrice24.Name = "txtPrice24";
            txtPrice24.Size = new Size(154, 27);
            txtPrice24.TabIndex = 29;
            // 
            // txtQuantity32
            // 
            txtQuantity32.Location = new Point(260, 472);
            txtQuantity32.Name = "txtQuantity32";
            txtQuantity32.Size = new Size(178, 27);
            txtQuantity32.TabIndex = 30;
            // 
            // txtQuantity27
            // 
            txtQuantity27.Location = new Point(260, 431);
            txtQuantity27.Name = "txtQuantity27";
            txtQuantity27.Size = new Size(178, 27);
            txtQuantity27.TabIndex = 31;
            // 
            // txtTotal24
            // 
            txtTotal24.Location = new Point(644, 385);
            txtTotal24.Name = "txtTotal24";
            txtTotal24.ReadOnly = true;
            txtTotal24.Size = new Size(144, 27);
            txtTotal24.TabIndex = 32;
            txtTotal24.TextChanged += textBox12_TextChanged;
            // 
            // txtTotal27
            // 
            txtTotal27.Location = new Point(644, 431);
            txtTotal27.Name = "txtTotal27";
            txtTotal27.ReadOnly = true;
            txtTotal27.Size = new Size(144, 27);
            txtTotal27.TabIndex = 33;
            // 
            // txtTotal32
            // 
            txtTotal32.Location = new Point(644, 475);
            txtTotal32.Name = "txtTotal32";
            txtTotal32.ReadOnly = true;
            txtTotal32.Size = new Size(144, 27);
            txtTotal32.TabIndex = 34;
            // 
            // txtSubtotal
            // 
            txtSubtotal.Location = new Point(576, 514);
            txtSubtotal.Name = "txtSubtotal";
            txtSubtotal.ReadOnly = true;
            txtSubtotal.Size = new Size(193, 27);
            txtSubtotal.TabIndex = 35;
            // 
            // txtTaxes
            // 
            txtTaxes.Location = new Point(576, 547);
            txtTaxes.Name = "txtTaxes";
            txtTaxes.ReadOnly = true;
            txtTaxes.Size = new Size(193, 27);
            txtTaxes.TabIndex = 36;
            txtTaxes.Text = "0.18";
            // 
            // txtFinalTotal
            // 
            txtFinalTotal.Location = new Point(576, 583);
            txtFinalTotal.Name = "txtFinalTotal";
            txtFinalTotal.ReadOnly = true;
            txtFinalTotal.Size = new Size(193, 27);
            txtFinalTotal.TabIndex = 37;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 659);
            Controls.Add(txtFinalTotal);
            Controls.Add(txtTaxes);
            Controls.Add(txtSubtotal);
            Controls.Add(txtTotal32);
            Controls.Add(txtTotal27);
            Controls.Add(txtTotal24);
            Controls.Add(txtQuantity27);
            Controls.Add(txtQuantity32);
            Controls.Add(txtPrice24);
            Controls.Add(txtPrice27);
            Controls.Add(txtPrice32);
            Controls.Add(txtQuantity24);
            Controls.Add(txtAddress1);
            Controls.Add(txtAddress2);
            Controls.Add(txtCompanyName);
            Controls.Add(txtInvoiceDate);
            Controls.Add(txtInvoiceNumber);
            Controls.Add(btnClear);
            Controls.Add(btnCalculate);
            Controls.Add(btnSave);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Button btnSave;
        private Button btnCalculate;
        private Button btnClear;
        private TextBox txtInvoiceNumber;
        private TextBox txtInvoiceDate;
        private TextBox txtCompanyName;
        private TextBox txtAddress2;
        private TextBox txtAddress1;
        private TextBox txtQuantity24;
        private TextBox txtPrice32;
        private TextBox txtPrice27;
        private TextBox txtPrice24;
        private TextBox txtQuantity32;
        private TextBox txtQuantity27;
        private TextBox txtTotal24;
        private TextBox txtTotal27;
        private TextBox txtTotal32;
        private TextBox txtSubtotal;
        private TextBox txtTaxes;
        private TextBox txtFinalTotal;
    }
}
