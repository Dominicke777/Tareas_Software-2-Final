﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BanderaQuiz
{
    public partial class Form1 : Form
    {

        private int currentRound = 0; // Contador de rondas actuales
        private const int MaxRounds = 35; // Límite de rondas

        private Dictionary<string, Image> countryFlags;
        private string currentCountry;
        private int score = 0;
        private int totalQuestions = 0;
        private Random random = new Random();
        private const int MaxScore = 35;

        public Form1()
        {
            InitializeComponent();
            InitializeCountryFlags();
            SetupInitialUI();
        }

        private void InitializeCountryFlags()
        {
            // Aquí deberías cargar las imágenes de las banderas desde una carpeta o recursos
            // Este es un ejemplo con algunos países (necesitarías tener las imágenes)
            countryFlags = new Dictionary<string, Image>
            {
                { "Argentina", Properties.Resources.Argentina },
                { "Brasil", Properties.Resources.Brasil },
                { "Canadá", Properties.Resources.Canada },
                { "China", Properties.Resources.China },
                { "Francia", Properties.Resources.Francia },
                { "Alemania", Properties.Resources.Alemania },
                { "India", Properties.Resources.India },
                { "Japón", Properties.Resources.Japon },
                { "México", Properties.Resources.Mexico },
                { "Rusia", Properties.Resources.Rusia },
                { "España", Properties.Resources.España },
                { "Reino Unido", Properties.Resources.ReinoUnido },
                { "EEUU", Properties.Resources.EEUU }
                // Agrega más países según necesites
            };

            totalQuestions = countryFlags.Count;
        }



        private void SetupInitialUI()
        {
            // Configuración inicial de la interfaz
            txtFlag.Text = "Flag:";
            txtResult.ReadOnly = true;
            txtEvaluation.ReadOnly = true;
            txtEvaluation.Visible = false;

            // Llenar el ComboBox con los países
            cmbCountry.Items.Clear();
            foreach (var country in countryFlags.Keys)
            {
                cmbCountry.Items.Add(country);
            }

            btnNextFlag.Enabled = false;
            ShowRandomFlag();
        }

        private void ShowRandomFlag()
        {
            if (currentRound >= MaxRounds || countryFlags.Count == 0)
            {
                EndQuiz();
                return;
            }

            // Incrementar el contador de rondas
            currentRound++;

            // Seleccionar un país aleatorio
            int index = random.Next(0, countryFlags.Count);
            int currentIndex = 0;
            foreach (var country in countryFlags.Keys)
            {
                if (currentIndex == index)
                {
                    currentCountry = country;
                    break;
                }
                currentIndex++;
            }

            // Mostrar la bandera
            pictureBox1.Image = countryFlags[currentCountry];
            cmbCountry.SelectedIndex = -1;
            txtResult.Text = "";
        }




        private void EndQuiz()
        {
            // Desactivar controles
            btnSubmit.Enabled = false;
            cmbCountry.Enabled = false;
            btnNextFlag.Enabled = false;
            pictureBox1.Image = null;

            // Mostrar evaluación final
            txtEvaluation.Visible = true;
            txtEvaluation.Text = GetEvaluationText();

            MessageBox.Show("¡El juego ha terminado! Has completado las 35 rondas.", "Fin del Juego", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private string GetEvaluationText()
        {
            // Calcula el porcentaje basado en MaxRounds (35 rondas)
            double percentage = (double)score / MaxRounds * 100;
            string evaluation;

            // Determina la evaluación en base al porcentaje
            if (percentage <= 20) evaluation = "Fail";
            else if (percentage <= 40) evaluation = "Poor";
            else if (percentage <= 60) evaluation = "Good";
            else if (percentage <= 80) evaluation = "Very Good";
            else evaluation = "Excellent";

            // Devuelve el texto de la evaluación
            return $"Puntuación: {score}/{MaxRounds} - {evaluation}";
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // Removed the duplicate definition of ShowRandomFlag method.  
        // The second definition of ShowRandomFlag is redundant and causes the CS0111 error.  
        // Keeping only the first definition of ShowRandomFlag.  

        

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            if (cmbCountry.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona un país", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedCountry = cmbCountry.SelectedItem.ToString();
            bool isCorrect = selectedCountry == currentCountry;

            if (isCorrect)
            {
                score++;
                txtResult.Text = "¡Correcto!";
                txtResult.BackColor = Color.LightGreen;
            }
            else
            {
                txtResult.Text = $"Incorrecto. La respuesta correcta era: {currentCountry}";
                txtResult.BackColor = Color.LightPink;
            }

            // Eliminar la bandera ya mostrada para no repetir (COMENTAR O ELIMINAR ESTA LÍNEA)
            // countryFlags.Remove(currentCountry);

            btnSubmit.Enabled = false;
            cmbCountry.Enabled = false;
            btnNextFlag.Enabled = true;
        }


        private void btnNextFlag_Click_1(object sender, EventArgs e)
        {
            btnSubmit.Enabled = true;
            cmbCountry.Enabled = true;
            btnNextFlag.Enabled = false;
            txtResult.BackColor = SystemColors.Window;

            ShowRandomFlag();
        }
    }
}
