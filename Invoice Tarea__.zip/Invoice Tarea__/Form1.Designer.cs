﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            txtInvoiceNumber = new TextBox();
            txtInvoiceDate = new TextBox();
            txtCompanyName = new TextBox();
            txtQuantity24 = new TextBox();
            txtAddress2 = new TextBox();
            txtAddress1 = new TextBox();
            txtPrice27 = new TextBox();
            txtQuantity27 = new TextBox();
            txtQuantity32 = new TextBox();
            txtPrice32 = new TextBox();
            txtPrice24 = new TextBox();
            txtTotal27 = new TextBox();
            txtTotal24 = new TextBox();
            txtTotal32 = new TextBox();
            txtFinalTotal = new TextBox();
            txtTaxes = new TextBox();
            txtSubtotal = new TextBox();
            btnSave = new Button();
            btnTaxes = new Button();
            btnClear = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(289, 36);
            label1.Name = "label1";
            label1.Size = new Size(243, 41);
            label1.TabIndex = 0;
            label1.Text = "Monitor Invoice";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(359, 534);
            label3.Name = "label3";
            label3.Size = new Size(42, 20);
            label3.TabIndex = 2;
            label3.Text = "Total";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(357, 496);
            label4.Name = "label4";
            label4.Size = new Size(44, 20);
            label4.TabIndex = 3;
            label4.Text = "Taxes";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(151, 417);
            label5.Name = "label5";
            label5.Size = new Size(31, 20);
            label5.TabIndex = 4;
            label5.Text = "32\"";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(151, 336);
            label6.Name = "label6";
            label6.Size = new Size(31, 20);
            label6.TabIndex = 5;
            label6.Text = "24\"";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(151, 297);
            label7.Name = "label7";
            label7.Size = new Size(43, 20);
            label7.TabIndex = 6;
            label7.Text = "Type:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(472, 297);
            label8.Name = "label8";
            label8.Size = new Size(48, 20);
            label8.TabIndex = 7;
            label8.Text = "Totals";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(253, 297);
            label9.Name = "label9";
            label9.Size = new Size(68, 20);
            label9.TabIndex = 8;
            label9.Text = "Quantity:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(106, 248);
            label10.Name = "label10";
            label10.Size = new Size(115, 20);
            label10.TabIndex = 9;
            label10.Text = "Address (Line 2)";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(357, 447);
            label11.Name = "label11";
            label11.Size = new Size(65, 20);
            label11.TabIndex = 10;
            label11.Text = "Subtotal";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(151, 381);
            label12.Name = "label12";
            label12.Size = new Size(31, 20);
            label12.TabIndex = 11;
            label12.Text = "27\"";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(357, 297);
            label13.Name = "label13";
            label13.Size = new Size(44, 20);
            label13.TabIndex = 12;
            label13.Text = "Price:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(106, 210);
            label14.Name = "label14";
            label14.Size = new Size(115, 20);
            label14.TabIndex = 13;
            label14.Text = "Address (Line 1)";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(106, 164);
            label15.Name = "label15";
            label15.Size = new Size(116, 20);
            label15.TabIndex = 14;
            label15.Text = "Company name:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(455, 103);
            label16.Name = "label16";
            label16.Size = new Size(95, 20);
            label16.TabIndex = 15;
            label16.Text = "Invoice Date:";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(106, 103);
            label17.Name = "label17";
            label17.Size = new Size(117, 20);
            label17.TabIndex = 16;
            label17.Text = "Invoice Number:";
            // 
            // txtInvoiceNumber
            // 
            txtInvoiceNumber.Location = new Point(236, 100);
            txtInvoiceNumber.Name = "txtInvoiceNumber";
            txtInvoiceNumber.Size = new Size(179, 27);
            txtInvoiceNumber.TabIndex = 17;
            // 
            // txtInvoiceDate
            // 
            txtInvoiceDate.Location = new Point(556, 96);
            txtInvoiceDate.Name = "txtInvoiceDate";
            txtInvoiceDate.Size = new Size(177, 27);
            txtInvoiceDate.TabIndex = 18;
            // 
            // txtCompanyName
            // 
            txtCompanyName.Location = new Point(253, 164);
            txtCompanyName.Name = "txtCompanyName";
            txtCompanyName.Size = new Size(445, 27);
            txtCompanyName.TabIndex = 19;
            // 
            // txtQuantity24
            // 
            txtQuantity24.Location = new Point(236, 329);
            txtQuantity24.Name = "txtQuantity24";
            txtQuantity24.Size = new Size(81, 27);
            txtQuantity24.TabIndex = 20;
            // 
            // txtAddress2
            // 
            txtAddress2.Location = new Point(253, 248);
            txtAddress2.Name = "txtAddress2";
            txtAddress2.Size = new Size(445, 27);
            txtAddress2.TabIndex = 21;
            // 
            // txtAddress1
            // 
            txtAddress1.Location = new Point(253, 210);
            txtAddress1.Name = "txtAddress1";
            txtAddress1.Size = new Size(445, 27);
            txtAddress1.TabIndex = 22;
            // 
            // txtPrice27
            // 
            txtPrice27.Location = new Point(345, 374);
            txtPrice27.Name = "txtPrice27";
            txtPrice27.Size = new Size(81, 27);
            txtPrice27.TabIndex = 23;
            // 
            // txtQuantity27
            // 
            txtQuantity27.Location = new Point(236, 374);
            txtQuantity27.Name = "txtQuantity27";
            txtQuantity27.Size = new Size(81, 27);
            txtQuantity27.TabIndex = 24;
            // 
            // txtQuantity32
            // 
            txtQuantity32.Location = new Point(236, 410);
            txtQuantity32.Name = "txtQuantity32";
            txtQuantity32.Size = new Size(81, 27);
            txtQuantity32.TabIndex = 25;
            // 
            // txtPrice32
            // 
            txtPrice32.Location = new Point(345, 410);
            txtPrice32.Name = "txtPrice32";
            txtPrice32.Size = new Size(81, 27);
            txtPrice32.TabIndex = 26;
            // 
            // txtPrice24
            // 
            txtPrice24.Location = new Point(345, 329);
            txtPrice24.Name = "txtPrice24";
            txtPrice24.Size = new Size(81, 27);
            txtPrice24.TabIndex = 27;
            // 
            // txtTotal27
            // 
            txtTotal27.Location = new Point(472, 374);
            txtTotal27.Name = "txtTotal27";
            txtTotal27.ReadOnly = true;
            txtTotal27.Size = new Size(81, 27);
            txtTotal27.TabIndex = 28;
            // 
            // txtTotal24
            // 
            txtTotal24.Location = new Point(472, 329);
            txtTotal24.Name = "txtTotal24";
            txtTotal24.ReadOnly = true;
            txtTotal24.Size = new Size(81, 27);
            txtTotal24.TabIndex = 29;
            // 
            // txtTotal32
            // 
            txtTotal32.Location = new Point(472, 414);
            txtTotal32.Name = "txtTotal32";
            txtTotal32.ReadOnly = true;
            txtTotal32.Size = new Size(81, 27);
            txtTotal32.TabIndex = 30;
            // 
            // txtFinalTotal
            // 
            txtFinalTotal.Location = new Point(472, 531);
            txtFinalTotal.Name = "txtFinalTotal";
            txtFinalTotal.ReadOnly = true;
            txtFinalTotal.Size = new Size(81, 27);
            txtFinalTotal.TabIndex = 31;
            // 
            // txtTaxes
            // 
            txtTaxes.Location = new Point(472, 489);
            txtTaxes.Name = "txtTaxes";
            txtTaxes.ReadOnly = true;
            txtTaxes.Size = new Size(81, 27);
            txtTaxes.TabIndex = 32;
            txtTaxes.Text = "0.18";
            // 
            // txtSubtotal
            // 
            txtSubtotal.Location = new Point(472, 447);
            txtSubtotal.Name = "txtSubtotal";
            txtSubtotal.ReadOnly = true;
            txtSubtotal.Size = new Size(81, 27);
            txtSubtotal.TabIndex = 33;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(82, 447);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(221, 29);
            btnSave.TabIndex = 34;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnTaxes
            // 
            btnTaxes.Location = new Point(82, 487);
            btnTaxes.Name = "btnTaxes";
            btnTaxes.Size = new Size(221, 29);
            btnTaxes.TabIndex = 35;
            btnTaxes.Text = "Calculate";
            btnTaxes.UseVisualStyleBackColor = true;
            btnTaxes.Click += btnTaxes_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(82, 531);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(221, 29);
            btnClear.TabIndex = 36;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 598);
            Controls.Add(btnClear);
            Controls.Add(btnTaxes);
            Controls.Add(btnSave);
            Controls.Add(txtSubtotal);
            Controls.Add(txtTaxes);
            Controls.Add(txtFinalTotal);
            Controls.Add(txtTotal32);
            Controls.Add(txtTotal24);
            Controls.Add(txtTotal27);
            Controls.Add(txtPrice24);
            Controls.Add(txtPrice32);
            Controls.Add(txtQuantity32);
            Controls.Add(txtQuantity27);
            Controls.Add(txtPrice27);
            Controls.Add(txtAddress1);
            Controls.Add(txtAddress2);
            Controls.Add(txtQuantity24);
            Controls.Add(txtCompanyName);
            Controls.Add(txtInvoiceDate);
            Controls.Add(txtInvoiceNumber);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private TextBox txtInvoiceNumber;
        private TextBox txtInvoiceDate;
        private TextBox txtCompanyName;
        private TextBox txtQuantity24;
        private TextBox txtAddress2;
        private TextBox txtAddress1;
        private TextBox txtPrice27;
        private TextBox txtQuantity27;
        private TextBox txtQuantity32;
        private TextBox txtPrice32;
        private TextBox txtPrice24;
        private TextBox txtTotal27;
        private TextBox txtTotal24;
        private TextBox txtTotal32;
        private TextBox txtFinalTotal;
        private TextBox txtTaxes;
        private TextBox txtSubtotal;
        private Button btnSave;
        private Button btnTaxes;
        private Button btnClear;
    }
}
