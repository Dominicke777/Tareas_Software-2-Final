namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnTaxes_Click(object sender, EventArgs e)
        {
            try
            {
                // Calcular total para 24"
                if (!string.IsNullOrEmpty(txtQuantity24.Text) && !string.IsNullOrEmpty(txtQuantity24.Text))
                {
                    double quantity = Convert.ToDouble(txtQuantity24.Text);
                    double price = Convert.ToDouble(txtQuantity24.Text);
                    txtTotal24.Text = (quantity * price).ToString("0.00");
                }

                // Calcular total para 27"
                if (!string.IsNullOrEmpty(txtQuantity27.Text) && !string.IsNullOrEmpty(txtPrice27.Text))
                {
                    double quantity = Convert.ToDouble(txtQuantity27.Text);
                    double price = Convert.ToDouble(txtPrice27.Text);
                    txtTotal27.Text = (quantity * price).ToString("0.00");
                }

                // Calcular total para 32"
                if (!string.IsNullOrEmpty(txtQuantity32.Text) && !string.IsNullOrEmpty(txtPrice32.Text))
                {
                    double quantity = Convert.ToDouble(txtQuantity32.Text);
                    double price = Convert.ToDouble(txtPrice32.Text);
                    txtTotal32.Text = (quantity * price).ToString("0.00");
                }

                // Calcular subtotal
                double subtotal = 0;
                if (!string.IsNullOrEmpty(txtTotal24.Text)) subtotal += Convert.ToDouble(txtTotal24.Text);
                if (!string.IsNullOrEmpty(txtTotal27.Text)) subtotal += Convert.ToDouble(txtTotal27.Text);
                if (!string.IsNullOrEmpty(txtTotal32.Text)) subtotal += Convert.ToDouble(txtTotal32.Text);
                txtSubtotal.Text = subtotal.ToString("0.00");

                // Calcular impuestos y total final
                double taxRate = Convert.ToDouble(txtTaxes.Text);
                double taxes = subtotal * taxRate;
                double finalTotal = subtotal + taxes;
                txtFinalTotal.Text = finalTotal.ToString("0.00");

                // Verificar que todos los campos est�n llenos
                if (string.IsNullOrWhiteSpace(txtInvoiceNumber.Text) ||
                    string.IsNullOrWhiteSpace(txtInvoiceDate.Text) ||
                    string.IsNullOrWhiteSpace(txtCompanyName.Text) ||
                    string.IsNullOrWhiteSpace(txtAddress1.Text) ||
                    string.IsNullOrWhiteSpace(txtAddress2.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity24.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity24.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity27.Text) ||
                    string.IsNullOrWhiteSpace(txtPrice27.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity32.Text) ||
                    string.IsNullOrWhiteSpace(txtPrice32.Text))
                {

                    txtInvoiceNumber.Clear();
                    txtInvoiceDate.Clear();
                    txtCompanyName.Clear();
                    txtAddress1.Clear();
                    txtAddress2.Clear();

                    txtQuantity24.Clear();
                    txtPrice24.Clear();
                    txtQuantity27.Clear();
                    txtPrice27.Clear();
                    txtQuantity32.Clear();
                    txtPrice32.Clear();

                    // Limpiar campos calculados
                    txtTotal24.Clear();
                    txtTotal27.Clear();
                    txtTotal32.Clear();
                    txtSubtotal.Clear();
                    txtFinalTotal.Clear();
                    MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en los datos ingresados: " + ex.Message);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Limpiar todos los campos editables
            txtInvoiceNumber.Clear();
            txtInvoiceDate.Clear();
            txtCompanyName.Clear();
            txtAddress1.Clear();
            txtAddress2.Clear();

            txtQuantity24.Clear();
            txtPrice24.Clear();
            txtQuantity27.Clear();
            txtPrice27.Clear();
            txtQuantity32.Clear();
            txtPrice32.Clear();

            // Limpiar campos calculados
            txtTotal24.Clear();
            txtTotal27.Clear();
            txtTotal32.Clear();
            txtSubtotal.Clear();
            txtFinalTotal.Clear();

            // Restablecer impuestos
            txtFinalTotal.Text = "0.18";


        }

    }
}
