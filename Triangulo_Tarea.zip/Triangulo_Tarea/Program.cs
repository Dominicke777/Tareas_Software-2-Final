﻿
using System;

namespace TrianguloApp
    {
        class Triangulo
        {
            private double ladoA;
            private double ladoB;
            private double ladoC;

            public Triangulo(double a, double b, double c)
            {
                ladoA = a;
                ladoB = b;
                ladoC = c;
            }

            public void MostrarLados()
            {
                Console.WriteLine($"Lados del triángulo: A = {ladoA}, B = {ladoB}, C = {ladoC}");
            }

            public bool EsTrianguloValido()
            {
                return (ladoA + ladoB > ladoC) &&
                       (ladoA + ladoC > ladoB) &&
                       (ladoB + ladoC > ladoA);
            }

            public void MostrarTipo()
            {
                if (!EsTrianguloValido())
                {
                    Console.WriteLine("Estos lados NO forman un triángulo válido.");
                    return;
                }

                if (ladoA == ladoB && ladoB == ladoC)
                {
                    Console.WriteLine("Es un triángulo Equilátero.");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    Console.WriteLine("Es un triángulo Isósceles.");
                }
                else
                {
                    Console.WriteLine("Es un triángulo Escaleno.");
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Ingrese el primer lado:");
                double a = double.Parse(Console.ReadLine());

                Console.WriteLine("Ingrese el segundo lado:");
                double b = double.Parse(Console.ReadLine());

                Console.WriteLine("Ingrese el tercer lado:");
                double c = double.Parse(Console.ReadLine());

                Triangulo t = new Triangulo(a, b, c);

                Console.WriteLine();
                t.MostrarLados();
                Console.WriteLine();

                if (t.EsTrianguloValido())
                {
                    Console.WriteLine("Los lados forman un triángulo válido.");
                    t.MostrarTipo();
                }
                else
                {
                    Console.WriteLine("Los lados NO forman un triángulo válido.");
                }

                Console.WriteLine("\nPresione cualquier tecla para salir...");
                Console.ReadKey();
            }
        }
    }
